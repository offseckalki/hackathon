
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

const sponsors = ["LeetCode", "Azure", "Hewlett Packard", "TCS"];

const sponsorLogos = [
  {
    name: "LeetCode",
    src: "https://assets.leetcode.com/static_assets/public/icons/favicon-96x96.png"
  },
  {
    name: "Azure",
    src: "https://azure.microsoft.com/favicon.ico"
  },
  {
    name: "Hewlett Packard",
    src: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/HP_logo_2012.svg/768px-HP_logo_2012.svg.png"
  },
  {
    name: "TCS",
    src: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Tata_Consultancy_Services_Logo.svg/512px-Tata_Consultancy_Services_Logo.svg.png"
  }
];

const Layout = ({ children }) => (
  <div className="min-h-screen bg-gradient-to-br from-purple-900 via-slate-900 to-gray-800 text-white">
    <header className="p-6 flex justify-between items-center border-b border-purple-600">
      <h1 className="text-3xl font-bold text-yellow-300">iSHEFT presents CodeClash Dharamshala</h1>
      <nav className="space-x-6">
        <Link to="/" className="hover:text-yellow-300">Home</Link>
        <Link to="/idea" className="hover:text-yellow-300">Hackathon Idea</Link>
        <Link to="/problems" className="hover:text-yellow-300">Problem Statements</Link>
        <Link to="/rules" className="hover:text-yellow-300">Rules</Link>
      </nav>
    </header>
    <main className="p-6 max-w-6xl mx-auto">{children}</main>
    <footer className="p-4 border-t border-purple-600 text-center text-sm text-gray-300 mt-12">
      Hosted by iSHEFT • Sponsored by {sponsors.join(", ")} | © 2025 CodeClash
    </footer>
  </div>
);

// [Shortened for brevity — would include full code here]
export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/idea" element={<IdeaPage />} />
          <Route path="/problems" element={<ProblemsPage />} />
          <Route path="/rules" element={<RulesPage />} />
        </Routes>
      </Layout>
    </Router>
  );
}
